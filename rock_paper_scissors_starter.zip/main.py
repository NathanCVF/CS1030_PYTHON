from random import randint

player = input('rock (r), paper (p) or scissors (s)?')
#The set of prompts that will be assigned
print(player, 'vs')
#The command to set if you want to be comparing a value to a computer
chosen = randint(1,3)
print(chosen)
#The range of possible numbers the computer may chose from at random
if(chosen == 1):
    computer = 'r'

elif(chosen == 2):
    computer = 'p'

else:
  computer = 's'

print(computer)
#From lines 9 to 18 numbers are the values the computer can choose from, each value is assigned to a number that gets randomly chosen. If the first two values aren't chosen then the computer will default to what isn't listed, 3.

if(player == computer):
    print('DRAW!')

elif(player == 'r' and computer == 's'):
    print('Player wins!')

elif(player == 'r' and computer == 'p'):
    print('Computer wins!')
#Lines 21 to 28 are the conditions for either to win/draw with rock

elif(player == 'p' and computer == 'r'):
    print('Player wins!')

elif(player == 'p' and computer == 's'):
    print('Computer wins!')
#The conditions of true or false to win or draw with paper
elif(player == 's' and computer == 'p'):
    print('Player wins!')

elif(player == 's' and computer == 'r'):
    print('Computer wins!')
    #The conditions for either the player or computer to win or draw with scissors
    